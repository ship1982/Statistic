<?php

session_start();

include_once __DIR__ . '/Lacanich.php';
include_once __DIR__ . '/LacanichSequencer.php';

/**
 * Example
 */
$counter = new Lacanich();
// get config json file
$counter->configFile = __DIR__ . '/config.json';
// check acces token and see have we $_GET[code]
if(!$counter->checkAccessToken()
	&& !$counter->checkCode()
)
	echo $counter->authorize();
else
{
	// get access token
	$counter->getAccessToken();

	// get sequencer data
	$sequencer = new LacanichSequencer();
	$sequencer->setDateRange('05.12.2016 23:13:53');
	$sequencer->setFields(['utm_term','utm_content','utm_source','utm_medium','utm_campaign']);
	$sequencer->setCondition([
		'link_text' => [
			'type' => 'regexp',
			'value' => 'success_FID1'
		]
	]);

	$body = $sequencer->get();

	$answer = $counter->http(
		$sequencer->uri,
		$body['body'],
		$body['header']
	);

	// answer form API
	print_r($answer);
}