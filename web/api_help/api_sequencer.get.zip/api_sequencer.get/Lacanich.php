<?php

/**
 * Class for making query and authorize to Lacanich API.
 * 
 * Example usage:
 * $counter = new Lacanich();
 * $counter->configFile = __DIR__ . '/config.json';
 * if(!$counter->checkAccessToken()
 * 	&& !$counter->checkCode()
 * )
 * 		echo $counter->authorize();
 * else
 * {
 *		$counter->getAccessToken();
 * 
 * 		// запрос к конкретному ресурсу API
 * }
 *
 * @package Lacanich
 * @author Vitaly Khyakkinen <hva@zionec.ru>
 * @version 1.0
 * @access public
 */
class Lacanich
{
	/**
	 * @var string - url for oAuth2.0
	 */
	public $authURL = '';

	/**
	 * @var string - client_id for oAuth2.0
	 */
	public $client_id = '';
	
	/**
	 * @var string - redirect URI for oAuth2.0
	 */
	public $redirect_uri = '';

	/**
	 * @var string - path to config json file
	 */
	public $configFile = '';

	/**
	 * Set @see $authURL.
	 * 
	 * @param string $authURL @see $authURL.
	 * @return void
	 */
	public function setOAuthUrl($authURL = '')
	{
		if(!empty($authURL))
			$this->authURL = $authURL;
	}

	/**
	 * Get @see $authURL.
	 * 
	 * @return string @see $authURL
	 */
	public function getOAuthUrl()
	{
		if(empty($this->authURL))
			exit("Не задана ссылка для авторизации\n");

		return $this->authURL;
	}

	/**
	 * Check prameters in config file @see $configFile.
	 * Must be:
	 * outh - url for oAuth2.0.
	 * client_id - id of application in Lacanich.
	 * secret_key - generated secret string from Lacanich.
	 * redirect_uri - the URL in your application where users will be sent after authorization.
	 * 
	 * @param string $config - readed config file
	 * @return array config file in form an array.
	 */
	public function checkConfigFile($config = '')
	{
		if(!empty($config)
			&& is_string($config)
		)
		{
			$configArray = json_decode($config, true);
			if(empty($configArray['oath']))
				exit("Не указана ссылка для oAuth авторизации\n");

			if(empty($configArray['client_id']))
				exit("Не указан client_id\n");

			if(empty($configArray['secret_key']))
				exit("Не указан secret_key\n");

			if(empty($configArray['redirect_uri']))
				exit("Не указан redirect_uri\n");
		}

		return $configArray;
	}

	/**
	 * Get config file.
	 * 
	 * @return @see checkConfigFile
	 */
	public function getConfig()
	{
		if(empty($this->configFile)
			|| !file_exists($this->configFile)
		)
			exit("Не указан конфигурационный файл\n");

		$config = file_get_contents($this->configFile);
		return $this->checkConfigFile($config);
	}

	/**
	 * Get client id.
	 * 
	 * @return string - client id
	 */
	public function getClientId()
	{
		if(empty($this->client_id))
			exit("Не задано приложение.\n");

		return $this->client_id;
	}

	/**
	 * Set client id.
	 * 
	 * @return void
	 */
	public function setClientId($client_id = '')
	{
		if(empty($client_id))
			exit("Не задано приложение.\n");

		$this->client_id = $client_id;
	}

	/**
	 * Set redirect_uri.
	 * 
	 * @return void
	 */
	public function setRedirectUri($redirect_uri='')
	{
		if(empty($redirect_uri))
			exit("Не задано приложение.\n");

		$this->redirect_uri = $redirect_uri;
	}

	/**
	 * Get redirect_uri.
	 * 
	 * @return string - redirect_uri
	 */
	public function getRedirectUri()
	{
		if(empty($this->redirect_uri))
			exit("Не задана ссылка для перехода.\n");

		return $this->redirect_uri;
	}

	/**
	 * Do curl query to API.
	 * 
	 * @param string $url - url for query.
	 * @param string $data - post data @see setParams4Url().
	 * array('Content-Type: text/css', '')
	 * @param array $header - array of headers.
	 * @return string - answer form API
	 */
	public function http($url = '', $data = '', $header = [])
	{
		if(empty($url))
			exit("Не задана ссылка запроса\n");

		if( $curl = curl_init() )
		{
		  curl_setopt($curl, CURLOPT_URL, $url);
		  curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
		  curl_setopt($curl, CURLOPT_POST, true);
		  curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
		  curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		  $out = curl_exec($curl);
		  curl_close($curl);
		  return $out;
		}
		else
			exit("Не установлен curl\n");
	}

	/**
	 * Get response type equal response_type=code.
	 * 
	 * @return string
	 */
	public function getCode()
	{
		if(empty($this->authURL))
			exit("Не задана ссылка для авторизации.\n");

		return '?response_type=code';
	}
	
	/**
	 * Display form of authorization in Lacanich.
	 * 
	 * @return string - html
	 */
	public function authorize()
	{
		$config = $this->getConfig();
		$this->setClientId($config['client_id']);
		$this->setRedirectUri($config['redirect_uri']);
		$this->setOAuthUrl($config['oath']);
		$redirect_uri = $this->getRedirectUri();
		$url = $this->getOAuthUrl() .
			'authorize_code/' . 
			$this->getCode() .
			'&client_id=' . $this->getClientId() .
			'&redirect_uri=' . $this->getRedirectUri() . 
			'&state=' . rand(100, 999);
		return $this->http($url);
	}

	/**
	 * Set $_GET string without ?.
	 * 
	 * @param array $params - array of $_GET params
	 * @return type
	 */
	public function setParams4Url($params = [])
	{
		if(empty($params))
			exit("Не переданы параметры для url\n");
		$url = '';
		foreach ($params as $key => $value)
			$url .= $key . '=' . $value . '&';

		return substr($url, 0, -1);
	}

	/**
	 * If page has $_GET['code'], then return it.
	 * 
	 * @return string
	 */
	public function checkCode()
	{
		if(empty($_GET['code']))
			return false;

		return $_GET['code'];
	}

	/**
	 * Store token data in $_SESSION.
	 * 
	 * @param array $data - parsing of @see getAccessToken()
	 * @return void
	 */
	public function saveTokenData($data = [])
	{
		if(empty($data))
			exit("Не могу сохранить данные по токену\n");

		if(!empty($data['access_token'])
			&& !empty($data['expires_in'])
		)
		{
			$_SESSION['access_token'] = $data['access_token'];
			$_SESSION['expire'] = $data['expires_in'] + time();
		}
	}

	/**
	 * If token is expired return true.
	 * 
	 * @return bool
	 */
	public function isTokenExpired()
	{
		if($_SESSION['expire'] - time() <= 0)
			return true;
		else
			return false;
	}

	/**
	 * Check access token.
	 * 
	 * @return bool
	 */
	public function checkAccessToken()
	{
		if(!empty($_SESSION['access_token'])
			&& !$this->isTokenExpired()
		)
			return true;
		else
			return false;
	}

	/**
	 * Get access token for API.
	 * 
	 * @return string json
	 * {"access_token":"6f05ad622a3d32a5a81aee5d73a5826adb8cbf63","expires_in":3600,"token_type":"bearer","scope":null}
	 */
	public function getAccessToken()
	{
		if($this->checkAccessToken())
			return json_encode([
				'access_token' => $_SESSION['access_token'],
				'expire' => $_SESSION['expire']
			]);

		$config = $this->getConfig();
		$this->setClientId($config['client_id']);
		$this->setRedirectUri($config['redirect_uri']);
		$this->setOAuthUrl($config['oath']);
		$url = $this->authURL . 'gettoken/';
		$answer = $this->http(
			$url,
			$this->setParams4Url([
				'grant_type' => 'authorization_code',
				'code' => $this->checkCode(),
				'redirect_uri' => $this->getRedirectUri()
			]),
			['Authorization: Basic ' . base64_encode($config['client_id']. ':' . $config['secret_key'])]
		);

		if(!empty($answer))
		{
			$data = json_decode($answer, true);
			$this->saveTokenData($data);
			if(!empty($_SESSION['access_token'])
				&& !empty($_SESSION['expire'])
			)
			{
				return json_encode([
					'access_token' => $_SESSION['access_token'],
					'expire' => $_SESSION['expire']
				]);
			}
		}
	}

	/**
	 * Get stored token.
	 * 
	 * @return string - current token
	 */
	public function getOnlyToken()
	{
		if(!empty($_SESSION['access_token']))
			return $_SESSION['access_token'];
		else
			return '';
	}
}