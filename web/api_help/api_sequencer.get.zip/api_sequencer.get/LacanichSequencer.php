<?php

/**
 * Class for making query to sequencer Lacanich API.
 * 
 * Example of usage:
 * $sequencer = new LacanichSequencer();
 * $sequencer->setDateRange('21.11.2016 22:32:36');
 * $sequencer->setFields(['id','time','test','uuid','seance', 'utm_medium']);
 * $sequencer->setCondition([
 * 	'link' => [
 * 		'type' => 'regexp',
 * 		'value' => 'success_FID1.*[ID=187676]'
 * 	]
 * ]);
 * 
 * $body = $sequencer->get();
 * 
 * $answer = $counter->http(
 * 	$sequencer->uri,
 * 	$body['body'],
 * 	$body['header']
 * );
 * @package Lacanich
 * @author Vitaly Khyakkinen <hva@zionec.ru>
 * @version 1.0
 * @access public
 */
class LacanichSequencer
{
	/**
	 * @var int - version of API
	 */
	public $version = 1;

	/**
	 * @var string - url for API
	 */
	public $uri = "";

	/**
	 * @var string - host for API
	 */
	public $host = 'http://stat.mgts.zionec.ru/api/';

	/**
	 * @var string - application for API
	 */
	private $scope = 'api_sequencer.get';
	
	/**
	 * @var string - date range for query.
	 * If is a range, then string must be `firtstime-lasttime`
	 * if is not range, then string must be `firtstime`
	 * @see $this->setDateRange()
	 */
	public $dateRange = '';

	/**
	 * @var array - list of fields, which need to get.
	 */
	public $fields = [];

	/**
	 * @var array - list of condition
	 */
	public $condition = [];

	/**
	 * @constructor
	 */
	function __construct()
	{
		$this->uri = $this->host .
			'v' . $this->version .
			'/' . $this->scope;
	}

	/**
	 * Set a start time for query.
	 * @see @var dateRange
	 * 
	 * @param type|string $time - timestamp or human readable time.
	 * @return type string timestamp
	 */
	public function setStartTime($time = '')
	{
		if(empty($time)) 
			exit("Не задано начальное время!\n");

		if(!is_numeric($time))
			return strtotime($time);

		return $time;
	}

	/**
	 * Set a lst time for a query.
	 * @see @var dateRange
	 * 
	 * @param type|string $time - timestamp or human readable time.
	 * @return type string timestamp
	 */
	public function setEndTime($time = '')
	{
		if(!is_numeric($time))
			return strtotime($time);

		return $time;
	}

	/**
	 * Set date range for query @see dateRange.
	 * 
	 * @param type|string $start - @see setStartTime()
	 * @param type|string $end @see setEndTime()
	 * @return type @see dateRange
	 */
	public function setDateRange($start = '', $end = '')
	{
		$startTime = $this->setStartTime($start);
		$endTime = $this->setEndTime($end);
		if(!empty($startTime))
			$this->dateRange = $startTime;
		else
			exit("Ошибка задания времени!\n");

		if(!empty($endTime))
			$this->dateRange .= '-' . $endTime;
	}

	/**
	 * Set list of fields for query.
	 * @see @var fields.
	 * 
	 * @param type|array $list - @see @var fields.
	 * @return void
	 */
	public function setFields($list = [])
	{
		if(!empty($list)
			&& is_array($list)
		)
			$this->fields = $list;
	}

	/**
	 * Set condition for a query.
	 * 
	 * @param type|string $value - array with format
	 * `type` - type of condition
	 * '=' - equal,
	 * '!=' - not equal,
	 * '>' - greater,
	 * '<' - ,
	 * '>=',
	 * '<=',
	 * 'like',
	 * 'between',
	 * 'between_unix_time',
	 * 'regexp'
	 * @return type
	 */
	public function setCondition($value='')
	{
		if(!empty($value)
			&& is_array($value)
		)
		{
			foreach ($value as $condition => $params)
			{
				if(!empty($params['type'])
					&& !empty($params['value'])
				)
				{
					$this->condition[$condition] = [
						'type' => $params['type'],
						'value' => $params['value']
					];
				}
			}
		}
	}

	/**
	 * Get token form Lacanich.
	 * 
	 * @return type
	 */
	public function fetchToken()
	{
		if(!empty($_SESSION['access_token']))
			return $_SESSION['access_token'];
		else
			return '';
	}

	/**
	 * Set body and header for query.
	 * 
	 * @return array with body and header
	 */
	public function get()
	{
		if(empty($this->dateRange))
			exit("Ошибка задания времени!\n");

		$body['time'] = $this->dateRange;
		$body['fields'] = json_encode($this->fields);
		$body['conditions'] = json_encode($this->condition);
		$body['access_token'] = $this->fetchToken();

		return [
			'body' => http_build_query($body, '', '&'),
			'header' => ['Content-Type: application/x-www-form-urlencoded']
		];
	}
}